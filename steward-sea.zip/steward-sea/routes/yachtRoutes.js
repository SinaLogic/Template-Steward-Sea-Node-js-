const express = require('express');
const router = express.Router();
const {
  getYachts,
  getYachtById,
  getFilterRanges,
} = require('../controllers/yachtController');

router.get('/meta/ranges', getFilterRanges); // must precede /:id
router.get('/:id', getYachtById);
router.get('/', getYachts);

module.exports = router;
