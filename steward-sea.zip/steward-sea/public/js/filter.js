/**
 * filter.js — Sizes the filter sliders from the live data range, then
 * calls window.loadYachts() (defined in main.js) on every change so
 * results update in real time without a page reload.
 */

const filterForm = document.getElementById('filterForm');
const maxPriceInput = document.getElementById('maxPrice');
const maxLengthInput = document.getElementById('maxLength');
const maxPriceValue = document.getElementById('maxPriceValue');
const maxLengthValue = document.getElementById('maxLengthValue');
const featuredInput = document.getElementById('featuredOnly');
const sortInput = document.getElementById('sort');

const currencyShort = (n) =>
  n >= 1000000 ? `$${(n / 1000000).toFixed(1)}M` : `$${Math.round(n / 1000)}k`;

let debounceTimer = null;

function debounce(fn, delay = 200) {
  return (...args) => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => fn(...args), delay);
  };
}

function currentFilters() {
  return {
    maxPrice: maxPriceInput.value,
    maxLength: maxLengthInput.value,
    featured: featuredInput.checked ? 'true' : '',
    sort: sortInput.value,
  };
}

const applyFilters = debounce(() => {
  maxPriceValue.textContent = currencyShort(Number(maxPriceInput.value));
  maxLengthValue.textContent = `${maxLengthInput.value}m`;
  window.loadYachts(currentFilters());
});

/**
 * Pulls min/max bounds from the API so the sliders reflect the real
 * fleet instead of hardcoded guesses, then does an initial paint.
 */
async function initFilterRanges() {
  try {
    const res = await fetch('/api/yachts/meta/ranges');
    const { data } = await res.json();

    if (data && data.maxPrice) {
      maxPriceInput.min = data.minPrice;
      maxPriceInput.max = data.maxPrice;
      maxPriceInput.value = data.maxPrice;
      maxPriceValue.textContent = currencyShort(data.maxPrice);
    }

    if (data && data.maxLength) {
      maxLengthInput.min = data.minLength;
      maxLengthInput.max = data.maxLength;
      maxLengthInput.value = data.maxLength;
      maxLengthValue.textContent = `${data.maxLength}m`;
    }
  } catch (err) {
    // Fall back to sane static defaults if the ranges endpoint is unreachable
    console.error('[initFilterRanges]', err);
    maxPriceInput.min = 0;
    maxPriceInput.max = 20000000;
    maxPriceInput.value = 20000000;
    maxLengthInput.min = 0;
    maxLengthInput.max = 80;
    maxLengthInput.value = 80;
    maxPriceValue.textContent = currencyShort(20000000);
    maxLengthValue.textContent = '80m';
  }
}

filterForm.addEventListener('input', applyFilters);

document.addEventListener('DOMContentLoaded', initFilterRanges);
