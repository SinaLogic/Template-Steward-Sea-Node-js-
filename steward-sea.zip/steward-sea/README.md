# Steward Sea

Luxury yacht sales landing page. Node.js/Express backend (MVC), MongoDB
via Mongoose, vanilla HTML/CSS/JS frontend using the Fetch API for
real-time listing filters.

## Folder structure (MVC)

```
steward-sea/
├── server.js               # Express entry point
├── config/
│   └── db.js                # MongoDB connection
├── models/
│   └── Yacht.js              # Mongoose schema/model
├── controllers/
│   └── yachtController.js    # Aggregation-based filter logic
├── routes/
│   ├── yachtRoutes.js        # /api/yachts/*
│   └── viewRoutes.js         # / (serves the landing page)
├── views/
│   └── index.html            # Landing page markup
├── public/
│   ├── css/
│   │   ├── base.css          # Tokens, resets, typography
│   │   ├── layout.css        # Grids: hero, filter bar, fleet, footer
│   │   └── components.css    # Buttons, yacht cards, inputs
│   ├── js/
│   │   ├── main.js           # Fetch + render listings
│   │   └── filter.js         # Real-time filter wiring
│   ├── images/                # Hero + listing photography (add your own)
│   └── fonts/                 # Mospace font files, if licensed
├── seed/
│   └── seedYachts.js         # Sample fleet data
└── .env.example
```

## Setup

```bash
npm install
cp .env.example .env         # point MONGODB_URI at your instance
npm run seed                  # loads six sample listings
npm run dev                   # http://localhost:3000
```

## Notes

- **Images**: drop a hero photo at `public/images/hero-yacht.jpg` and
  listing photos at `public/images/yacht-0N.jpg` to match the seed data.
- **Mospace font**: not distributed on Google Fonts. If you have a
  license for it, add the woff2 file to `public/fonts/` — the
  `@font-face` rule in `base.css` is already wired up. Until then the
  credit line and spec labels fall back to a monospace stack.
- **API**:
  - `GET /api/yachts?maxPrice=&maxLength=&featured=&sort=` — filtered listings
  - `GET /api/yachts/meta/ranges` — min/max price & length for slider bounds
  - `GET /api/yachts/:id` — single listing
