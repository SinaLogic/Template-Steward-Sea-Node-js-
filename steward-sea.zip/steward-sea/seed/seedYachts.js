require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('../config/db');
const Yacht = require('../models/Yacht');

const yachts = [
  {
    name: 'Meridian 42',
    builder: 'Steward Sea Yard',
    heroImage: '/images/yacht-01.jpg',
    price: 4850000,
    lengthMeters: 42,
    topSpeedKnots: 28,
    engine: 'Twin MTU 16V2000',
    cabins: 4,
    guests: 8,
    year: 2025,
    location: 'Monaco',
    featured: true,
    summary: 'A low-slung profile built for open water, finished in hand-laid teak below deck.',
  },
  {
    name: 'Solstice 55',
    builder: 'Steward Sea Yard',
    heroImage: '/images/yacht-02.jpg',
    price: 8250000,
    lengthMeters: 55,
    topSpeedKnots: 24,
    engine: 'Triple Caterpillar C32',
    cabins: 5,
    guests: 10,
    year: 2024,
    location: 'Porto Cervo',
    featured: true,
    summary: 'Full-beam owner\u2019s suite forward, a design choice usually reserved for vessels twice her size.',
  },
  {
    name: 'Corsair 38',
    builder: 'Steward Sea Yard',
    heroImage: '/images/yacht-03.jpg',
    price: 3100000,
    lengthMeters: 38,
    topSpeedKnots: 32,
    engine: 'Twin MAN V12',
    cabins: 3,
    guests: 6,
    year: 2025,
    location: 'Fort Lauderdale',
    featured: false,
    summary: 'Built for speed without surrendering the joinery and quiet you expect at anchor.',
  },
  {
    name: 'Windward 61',
    builder: 'Steward Sea Yard',
    heroImage: '/images/yacht-04.jpg',
    price: 11400000,
    lengthMeters: 61,
    topSpeedKnots: 22,
    engine: 'Triple MTU 16V2000',
    cabins: 6,
    guests: 12,
    year: 2023,
    location: 'Palma de Mallorca',
    featured: true,
    summary: 'A sky lounge and fold-down beach club make this a vessel built for long seasons aboard.',
  },
  {
    name: 'Halyard 33',
    builder: 'Steward Sea Yard',
    heroImage: '/images/yacht-05.jpg',
    price: 1950000,
    lengthMeters: 33,
    topSpeedKnots: 30,
    engine: 'Twin Volvo Penta IPS',
    cabins: 2,
    guests: 4,
    year: 2025,
    location: 'Ibiza',
    featured: false,
    summary: 'The entry point into the fleet, without a compromise made on materials or finish.',
  },
  {
    name: 'Northstar 70',
    builder: 'Steward Sea Yard',
    heroImage: '/images/yacht-06.jpg',
    price: 16800000,
    lengthMeters: 70,
    topSpeedKnots: 20,
    engine: 'Quad MTU 16V2000',
    cabins: 7,
    guests: 14,
    year: 2024,
    location: 'Antibes',
    featured: true,
    summary: 'The flagship of the yard. A full-time crew of eight keeps her ready year-round.',
  },
];

async function seed() {
  await connectDB();
  await Yacht.deleteMany({});
  await Yacht.insertMany(yachts);
  console.log(`[seed] inserted ${yachts.length} yachts`);
  await mongoose.disconnect();
  process.exit(0);
}

seed().catch((err) => {
  console.error('[seed] failed:', err);
  process.exit(1);
});
