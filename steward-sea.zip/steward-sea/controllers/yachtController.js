const mongoose = require('mongoose');
const Yacht = require('../models/Yacht');

/**
 * GET /api/yachts
 * Real-time filter endpoint backing the frontend's Fetch API calls.
 * Supports: minPrice, maxPrice, minLength, maxLength, featured, sort
 * Built with an aggregation pipeline so filtering, sorting, and shaping
 * the response all happen in a single round trip to MongoDB.
 */
exports.getYachts = async (req, res) => {
  try {
    const {
      minPrice,
      maxPrice,
      minLength,
      maxLength,
      featured,
      sort = 'featured',
      limit = 24,
    } = req.query;

    const match = {};

    if (minPrice || maxPrice) {
      match.price = {};
      if (minPrice) match.price.$gte = Number(minPrice);
      if (maxPrice) match.price.$lte = Number(maxPrice);
    }

    if (minLength || maxLength) {
      match.lengthMeters = {};
      if (minLength) match.lengthMeters.$gte = Number(minLength);
      if (maxLength) match.lengthMeters.$lte = Number(maxLength);
    }

    if (featured === 'true') {
      match.featured = true;
    }

    const sortStage = {
      'price-asc': { price: 1 },
      'price-desc': { price: -1 },
      'length-desc': { lengthMeters: -1 },
      featured: { featured: -1, createdAt: -1 },
    }[sort] || { featured: -1, createdAt: -1 };

    const pipeline = [
      { $match: match },
      { $sort: sortStage },
      { $limit: Number(limit) },
      {
        $project: {
          name: 1,
          builder: 1,
          heroImage: 1,
          price: 1,
          lengthMeters: 1,
          topSpeedKnots: 1,
          engine: 1,
          cabins: 1,
          guests: 1,
          year: 1,
          location: 1,
          featured: 1,
          summary: 1,
        },
      },
    ];

    const yachts = await Yacht.aggregate(pipeline);

    res.status(200).json({
      success: true,
      count: yachts.length,
      data: yachts,
    });
  } catch (err) {
    console.error('[yachtController.getYachts]', err);
    res.status(500).json({ success: false, message: 'Unable to load yacht listings.' });
  }
};

/**
 * GET /api/yachts/:id
 */
exports.getYachtById = async (req, res) => {
  try {
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ success: false, message: 'Invalid yacht id.' });
    }

    const yacht = await Yacht.findById(id).lean();

    if (!yacht) {
      return res.status(404).json({ success: false, message: 'Yacht not found.' });
    }

    res.status(200).json({ success: true, data: yacht });
  } catch (err) {
    console.error('[yachtController.getYachtById]', err);
    res.status(500).json({ success: false, message: 'Unable to load yacht.' });
  }
};

/**
 * GET /api/yachts/meta/ranges
 * Returns min/max price and length across the fleet so the frontend
 * can size its filter sliders dynamically instead of hardcoding bounds.
 */
exports.getFilterRanges = async (req, res) => {
  try {
    const [ranges] = await Yacht.aggregate([
      {
        $group: {
          _id: null,
          minPrice: { $min: '$price' },
          maxPrice: { $max: '$price' },
          minLength: { $min: '$lengthMeters' },
          maxLength: { $max: '$lengthMeters' },
        },
      },
      { $project: { _id: 0 } },
    ]);

    res.status(200).json({ success: true, data: ranges || {} });
  } catch (err) {
    console.error('[yachtController.getFilterRanges]', err);
    res.status(500).json({ success: false, message: 'Unable to load filter ranges.' });
  }
};
