/**
 * main.js — Fetches yacht listings from the Express API and renders
 * them into the fleet grid. Talks to filter.js via a single
 * `loadYachts(params)` function that filter.js calls whenever an input
 * changes, so there's one source of truth for how listings get drawn.
 */

const fleetGrid = document.getElementById('fleetGrid');
const resultCount = document.getElementById('resultCount');

const currency = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
  maximumFractionDigits: 0,
});

function yachtCardTemplate(yacht) {
  const {
    name,
    heroImage,
    price,
    lengthMeters,
    topSpeedKnots,
    engine,
    location,
    featured,
  } = yacht;

  return `
    <article class="yacht-card">
      <div class="yacht-card__image" style="background-image:url('${heroImage}')">
        ${featured ? '<span class="yacht-card__badge">Featured</span>' : ''}
      </div>
      <div class="yacht-card__body">
        <h3 class="yacht-card__name">${escapeHTML(name)}</h3>
        <p class="yacht-card__location">${escapeHTML(location)}</p>
        <p class="yacht-card__price">${currency.format(price)}</p>
        <div class="yacht-card__specs">
          <div class="yacht-card__spec">
            <span class="yacht-card__spec-label">Length</span>
            <span class="yacht-card__spec-value">${lengthMeters}m</span>
          </div>
          <div class="yacht-card__spec">
            <span class="yacht-card__spec-label">Speed</span>
            <span class="yacht-card__spec-value">${topSpeedKnots}kn</span>
          </div>
          <div class="yacht-card__spec">
            <span class="yacht-card__spec-label">Engine</span>
            <span class="yacht-card__spec-value">${escapeHTML(engine)}</span>
          </div>
        </div>
      </div>
    </article>
  `;
}

function escapeHTML(str = '') {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

/**
 * Builds the query string and hits GET /api/yachts.
 * Exposed on window so filter.js can trigger it on every input event
 * without the two files needing a shared bundler/module setup.
 */
async function loadYachts(params = {}) {
  fleetGrid.setAttribute('aria-busy', 'true');

  const query = new URLSearchParams(
    Object.entries(params).filter(([, v]) => v !== '' && v !== undefined && v !== null)
  ).toString();

  try {
    const response = await fetch(`/api/yachts${query ? `?${query}` : ''}`);

    if (!response.ok) {
      throw new Error(`Request failed with status ${response.status}`);
    }

    const { data } = await response.json();
    renderYachts(data);
  } catch (err) {
    console.error('[loadYachts]', err);
    fleetGrid.innerHTML = `<p class="fleet__empty">Listings are temporarily unavailable. Please try again shortly.</p>`;
    resultCount.textContent = '';
  } finally {
    fleetGrid.removeAttribute('aria-busy');
  }
}

function renderYachts(yachts) {
  if (!yachts || yachts.length === 0) {
    fleetGrid.innerHTML = `<p class="fleet__empty">No yachts match those filters. Try widening your range.</p>`;
    resultCount.textContent = '0 listings';
    return;
  }

  fleetGrid.innerHTML = yachts.map(yachtCardTemplate).join('');
  resultCount.textContent = `${yachts.length} listing${yachts.length === 1 ? '' : 's'}`;
}

window.loadYachts = loadYachts;

document.addEventListener('DOMContentLoaded', () => {
  loadYachts();
});
