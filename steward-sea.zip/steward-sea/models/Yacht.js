const mongoose = require('mongoose');

const YachtSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    builder: { type: String, required: true, trim: true },
    heroImage: { type: String, required: true }, // path or URL to listing image
    price: { type: Number, required: true, index: true }, // stored in USD, integer
    lengthMeters: { type: Number, required: true, index: true },
    topSpeedKnots: { type: Number, required: true },
    engine: { type: String, required: true },
    cabins: { type: Number, required: true },
    guests: { type: Number, required: true },
    year: { type: Number, required: true },
    location: { type: String, required: true },
    featured: { type: Boolean, default: false, index: true },
    summary: { type: String, required: true, maxlength: 240 },
  },
  { timestamps: true }
);

// Compound index to support the price + length filter combo used by the UI
YachtSchema.index({ price: 1, lengthMeters: 1 });

module.exports = mongoose.model('Yacht', YachtSchema);
