require('dotenv').config();
const express = require('express');
const path = require('path');
const compression = require('compression');
const helmet = require('helmet');
const morgan = require('morgan');

const connectDB = require('./config/db');
const yachtRoutes = require('./routes/yachtRoutes');
const viewRoutes = require('./routes/viewRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

// --- Performance & security middleware --------------------------------
app.use(compression()); // gzip responses — matters most on the hero image + JSON payloads
app.use(
  helmet({
    contentSecurityPolicy: false, // relax for template use; lock down per-deployment
  })
);
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
app.use(express.json());

// --- Static assets (SEO: served with cache headers for repeat visits) -
app.use(
  express.static(path.join(__dirname, 'public'), {
    maxAge: process.env.NODE_ENV === 'production' ? '7d' : 0,
    etag: true,
  })
);

// --- Routes --------------------------------------------------------------
app.use('/api/yachts', yachtRoutes);
app.use('/', viewRoutes);

// --- 404 -----------------------------------------------------------------
app.use((req, res) => {
  res.status(404).json({ success: false, message: 'Not found.' });
});

// --- Error handler ---------------------------------------------------------
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ success: false, message: 'Internal server error.' });
});

async function start() {
  await connectDB();
  app.listen(PORT, () => {
    console.log(`[server] Steward Sea running on http://localhost:${PORT}`);
  });
}

start();
